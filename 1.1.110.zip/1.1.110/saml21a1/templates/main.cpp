/*
 * $projectname$.cpp
 *
 * Created: $date$
 * Author : $user$
 */ 


#include "sam.h"


int main(void)
{
    /* Initialize the SAM system */
    SystemInit();

    /* Replace with your application code */
    while (1) 
    {
    }
}
