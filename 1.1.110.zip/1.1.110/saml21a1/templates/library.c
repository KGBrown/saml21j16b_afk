/*
 * $projectname$.c
 *
 * Created: $date$
 * Author : $user$
 */ 

#include "sam.h"


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}
